/**
 * Demo class for Chain of Responsibility pattern. Shows how multiple objects
 * can handle a request without the sender knowing which object will handle it.
 */
public class Demo {
  public static void main(String[] args) {
    System.out.println("=== Chain of Responsibility Pattern Demo ===\n");

    // Create handlers
    Handler handlerA = new ConcreteHandlerA();
    Handler handlerB = new ConcreteHandlerB();
    Handler handlerC = new ConcreteHandlerC();

    // Chain them together
    handlerA.setSuccessor(handlerB);
    handlerB.setSuccessor(handlerC);

    System.out.println("Client: Sending request of level 2");
    handlerA.handleRequest("aa"); // Level 2, handled by HandlerA
    System.out.println();

    System.out.println("Client: Sending request of level 5");
    handlerA.handleRequest("eeeee"); // Level 5, handled by HandlerB
    System.out.println();

    System.out.println("Client: Sending request of level 8");
    handlerA.handleRequest("eeeeeeee"); // Level 8, handled by HandlerC
    System.out.println();

    System.out.println("Client: Sending request of level 10");
    handlerA.handleRequest("eeeeeeeeee"); // Level 10, handled by HandlerC
    System.out.println();

    System.out.println("\nChain of Responsibility pattern benefits:");
    System.out.println("1. Reduces coupling between sender and receiver");
    System.out.println("2. Increases flexibility in object interactions");
    System.out.println("3. Allows adding or removing responsibilities dynamically");
    System.out.println("4. Follows the Single Responsibility Principle");
  }
}
