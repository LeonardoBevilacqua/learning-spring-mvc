/**
 * ConcreteHandlerB - handles request levels 4-6. If the request is within its
 * level of expertise, it handles it. Otherwise, it forwards the request to its successor.
 */
public class ConcreteHandlerB extends Handler {
    @Override
    public void handleRequest(String request) {
        if (requestLevel(request) >= 4 && requestLevel(request) <= 6) {
            System.out.println("ConcreteHandlerB: Handling request: " + request);
        } else if (successor != null) {
            System.out.println("ConcreteHandlerB: Passing request to successor: " + request);
            successor.handleRequest(request);
        }
    }

    private int requestLevel(String request) {
        return request.length();
    }
}