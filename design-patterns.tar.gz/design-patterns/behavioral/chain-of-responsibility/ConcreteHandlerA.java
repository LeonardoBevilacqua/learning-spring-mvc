/**
 * ConcreteHandlerA - handles request levels 1-3. If the request is within its
 * level of expertise, it handles it. Otherwise, it forwards the request to its successor.
 */
public class ConcreteHandlerA extends Handler {
    @Override
    public void handleRequest(String request) {
        if (requestLevel(request) <= 3) {
            System.out.println("ConcreteHandlerA: Handling request: " + request);
        } else if (successor != null) {
            System.out.println("ConcreteHandlerA: Passing request to successor: " + request);
            successor.handleRequest(request);
        }
    }

    private int requestLevel(String request) {
        // Simple logic to determine request level
        return request.length(); // Just an example
    }
}