/**
 * ConcreteHandlerC - handles request levels 7 and above. If the request is within its
 * level of expertise, it handles it. Otherwise, it forwards the request to its successor.
 */
public class ConcreteHandlerC extends Handler {
    @Override
    public void handleRequest(String request) {
        if (requestLevel(request) >= 7) {
            System.out.println("ConcreteHandlerC: Handling request: " + request);
        } else if (successor != null) {
            System.out.println("ConcreteHandlerC: Passing request to successor: " + request);
            successor.handleRequest(request);
        }
    }

    private int requestLevel(String request) {
        return request.length();
    }
}