/**
 * ConcreteColleagueA - one of the Colleague objects. It communicates with
 * other colleagues through its mediator.
 */
public class ConcreteColleagueA extends Colleague {
    public ConcreteColleagueA(Mediator mediator) {
        super(mediator);
    }

    @Override
    public void send(String message) {
        System.out.println("ConcreteColleagueA: Sending message: \"" + message + "\"");
        mediator.send(message, this);
    }

    @Override
    public void receive(String message) {
        System.out.println("ConcreteColleagueA: Received message: \"" + message + "\"");
    }
}