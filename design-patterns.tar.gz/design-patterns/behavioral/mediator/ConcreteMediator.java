/**
 * ConcreteMediator - implements the Mediator interface and coordinates
 * communication between Colleague objects. It knows its colleagues and how they should communicate.
 */
public class ConcreteMediator implements Mediator {
    private ConcreteColleagueA colleagueA;
    private ConcreteColleagueB colleagueB;

    public void setColleagueA(ConcreteColleagueA colleagueA) {
        this.colleagueA = colleagueA;
    }

    public void setColleagueB(ConcreteColleagueB colleagueB) {
        this.colleagueB = colleagueB;
    }

    @Override
    public void send(String message, Colleague colleague) {
        if (colleague.equals(colleagueA)) {
            colleagueB.receive(message);
        } else if (colleague.equals(colleagueB)) {
            colleagueA.receive(message);
        }
    }
}