/**
 * Demo class for Mediator pattern.
 * Shows how the Mediator pattern reduces chaotic communication between objects.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Mediator Pattern Demo ===\n");

        // Create mediator
        ConcreteMediator mediator = new ConcreteMediator();

        // Create colleagues and register them with the mediator
        ConcreteColleagueA colleagueA = new ConcreteColleagueA(mediator);
        ConcreteColleagueB colleagueB = new ConcreteColleagueB(mediator);

        // Set colleagues in mediator
        mediator.setColleagueA(colleagueA);
        mediator.setColleagueB(colleagueB);

        System.out.println("ColleagueA and ColleagueB are registered with the mediator");
        System.out.println();

        System.out.println("Client: ColleagueA sends message to ColleagueB through mediator");
        colleagueA.send("Hello ColleagueB!");
        System.out.println();

        System.out.println("Client: ColleagueB sends message to ColleagueA through mediator");
        colleagueB.send("Hi ColleagueA! How are you?");
        System.out.println();

        System.out.println("Mediator pattern benefits:");
        System.out.println("1. Reduces coupling between colleagues");
        System.out.println("2. Centralizes control for communication between colleagues");
        System.out.println("3. Makes it easier to modify interactions between colleagues");
        System.out.println("4. Follows the Single Responsibility Principle");
    }
}