/**
 * Mediator - defines the interface for communicating with Colleague objects.
 */
public interface Mediator {
    void send(String message, Colleague colleague);
}