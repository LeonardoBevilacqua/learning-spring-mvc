/**
 * ConcreteColleagueB - another Colleague object. It communicates with
 * other colleagues through its mediator.
 */
public class ConcreteColleagueB extends Colleague {
    public ConcreteColleagueB(Mediator mediator) {
        super(mediator);
    }

    @Override
    public void send(String message) {
        System.out.println("ConcreteColleagueB: Sending message: \"" + message + "\"");
        mediator.send(message, this);
    }

    @Override
    public void receive(String message) {
        System.out.println("ConcreteColleagueB: Received message: \"" + message + "\"");
    }
}