/**
 * ConcreteVisitorA - implements each operation declared by Visitor.
 */
public class ConcreteVisitorA implements Visitor {
    @Override
    public void visitConcreteElementA(ConcreteElementA element) {
        System.out.println("ConcreteVisitorA: Visiting ConcreteElementA");
        element.operationA();
    }

    @Override
    public void visitConcreteElementB(ConcreteElementB element) {
        System.out.println("ConcreteVisitorA: Visiting ConcreteElementB");
        element.operationB();
    }
}