/**
 * ConcreteVisitorB - implements each operation declared by Visitor differently.
 */
public class ConcreteVisitorB implements Visitor {
    @Override
    public void visitConcreteElementA(ConcreteElementA element) {
        System.out.println("ConcreteVisitorB: Visiting ConcreteElementA");
        element.operationA();
    }

    @Override
    public void visitConcreteElementB(ConcreteElementB element) {
        System.out.println("ConcreteVisitorB: Visiting ConcreteElementB");
        element.operationB();
    }
}