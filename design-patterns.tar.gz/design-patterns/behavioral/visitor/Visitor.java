/**
 * Visitor - declares a visit operation for each type of ConcreteElement in the object structure.
 */
public interface Visitor {
    void visitConcreteElementA(ConcreteElementA element);
    void visitConcreteElementB(ConcreteElementB element);
}