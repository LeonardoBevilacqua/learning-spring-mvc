/**
 * Demo class for Visitor pattern.
 * Shows how the Visitor pattern lets you define a new operation without changing the classes of the elements.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Visitor Pattern Demo ===\n");

        // Create objects
        ObjectStructure objectStructure = new ObjectStructure();
        ConcreteElementA elementA = new ConcreteElementA();
        ConcreteElementB elementB = new ConcreteElementB();
        ConcreteVisitorA visitorA = new ConcreteVisitorA();
        ConcreteVisitorB visitorB = new ConcreteVisitorB();

        // Add elements to the structure
        objectStructure.addElement(elementA);
        objectStructure.addElement(elementB);

        System.out.println("Object structure contains: ConcreteElementA and ConcreteElementB");
        System.out.println();

        System.out.println("Client: Accepting visitor A");
        objectStructure.accept(visitorA);
        System.out.println();

        System.out.println("Client: Accepting visitor B");
        objectStructure.accept(visitorB);
        System.out.println();

        System.out.println("Visitor pattern benefits:");
        System.out.println("1. Allows adding new operations without modifying element classes");
        System.out.println("2. Follows the Open/Closed Principle");
        System.out.println("3. Groups related operations together in Visitor classes");
        System.out.println("4. Follows the Single Responsibility Principle");
    }
}