/**
 * ConcreteElementB - implements the accept operation.
 */
public class ConcreteElementB implements Element {
    @Override
    public void accept(Visitor visitor) {
        visitor.visitConcreteElementB(this);
    }

    public void operationB() {
        System.out.println("ConcreteElementB: Performing its special operation");
    }
}