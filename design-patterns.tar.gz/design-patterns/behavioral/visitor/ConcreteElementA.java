/**
 * ConcreteElementA - implements the accept operation.
 */
public class ConcreteElementA implements Element {
    @Override
    public void accept(Visitor visitor) {
        visitor.visitConcreteElementA(this);
    }

    public void operationA() {
        System.out.println("ConcreteElementA: Performing its special operation");
    }
}