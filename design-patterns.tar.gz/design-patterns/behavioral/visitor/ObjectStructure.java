import java.util.ArrayList;
import java.util.List;

/**
 * ObjectStructure - can enumerate its elements and may provide a high-level
 * interface to allow the Visitor to visit all elements.
 */
public class ObjectStructure {
    private List<Element> elements = new ArrayList<>();

    public void addElement(Element element) {
        elements.add(element);
    }

    public void removeElement(Element element) {
        elements.remove(element);
    }

    public void accept(Visitor visitor) {
        for (Element element : elements) {
            element.accept(visitor);
        }
    }
}