/**
 * Element - defines an accept operation that takes a Visitor as an argument.
 */
public interface Element {
    void accept(Visitor visitor);
}