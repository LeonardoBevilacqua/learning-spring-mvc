/**
 * ConcreteStrategyA - implements the Strategy interface with a specific algorithm.
 */
public class ConcreteStrategyA implements Strategy {
    @Override
    public void execute() {
        System.out.println("ConcreteStrategyA: Executing algorithm A");
    }
}