/**
 * Demo class for Strategy pattern. Shows how the Strategy pattern lets you
 * change the behavior of a class at runtime.
 */
public class Demo {
  public static void main(String[] args) {
    System.out.println("=== Strategy Pattern Demo ===\n");

    // Create strategies
    Strategy strategyA = new ConcreteStrategyA();
    Strategy strategyB = new ConcreteStrategyB();

    // Create context with initial strategy A
    Context context = new Context(strategyA);

    System.out.println("Context initial strategy: Algorithm A");
    System.out.println();

    System.out.println("Client: Executing context strategy");
    context.executeStrategy();
    System.out.println();

    System.out.println("Client: Changing context strategy to Algorithm B");
    context.setStrategy(strategyB);
    context.executeStrategy();
    System.out.println();

    System.out.println("Strategy pattern benefits:");
    System.out.println("1. Defines a family of algorithms and encapsulates them");
    System.out.println("2. Makes algorithms interchangeable within a family");
    System.out.println("3. Follows the Open/Closed Principle");
    System.out.println("4. Avoids using conditional statements for algorithm selection");
    System.out.println("5. Follows the Single Responsibility Principle");
  }
}
