/**
 * Strategy - declares an interface common to all supported algorithms.
 * Context uses this interface to call the algorithm defined by a ConcreteStrategy.
 */
public interface Strategy {
    void execute();
}