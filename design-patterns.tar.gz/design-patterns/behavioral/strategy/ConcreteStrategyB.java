/**
 * ConcreteStrategyB - implements the Strategy interface with a different algorithm.
 */
public class ConcreteStrategyB implements Strategy {
    @Override
    public void execute() {
        System.out.println("ConcreteStrategyB: Executing algorithm B");
    }
}