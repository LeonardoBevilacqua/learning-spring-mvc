/**
 * Command - declares an interface for executing an operation.
 */
public interface Command {
    void execute();
}