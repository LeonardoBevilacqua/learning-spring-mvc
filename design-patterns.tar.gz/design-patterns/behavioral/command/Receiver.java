/**
 * Receiver - knows how to perform the operations associated with carrying out
 * a request. Any class may serve as a Receiver.
 */
public class Receiver {
    public void action() {
        System.out.println("Receiver: Performing action");
    }
}