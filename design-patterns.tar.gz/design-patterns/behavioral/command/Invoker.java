/**
 * Invoker - asks the Command to carry out the request. It has a command object
 * and at some point, it calls the execute() method.
 */
public class Invoker {
    private Command command;

    public void setCommand(Command command) {
        this.command = command;
    }

    public void executeCommand() {
        System.out.println("Invoker: Executing command");
        command.execute();
    }
}