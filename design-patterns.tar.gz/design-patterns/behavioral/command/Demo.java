/**
 * Demo class for Command pattern.
 * Shows how the Command pattern encapsulates requests as objects.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Command Pattern Demo ===\n");

        // Create receiver
        Receiver receiver = new Receiver();

        // Create command and bind it to the receiver
        Command command = new ConcreteCommand(receiver);

        // Create invoker and set the command
        Invoker invoker = new Invoker();
        invoker.setCommand(command);

        System.out.println("Client: Calling invoker to execute command");
        invoker.executeCommand();
        System.out.println();

        System.out.println("\nCommand pattern benefits:");
        System.out.println("1. Decouples the object that invokes the operation from the one that performs it");
        System.out.println("2. Allows easy addition of new commands");
        System.out.println("3. Supports undo/redo operations");
        System.out.println("4. Supports logging and queuing of requests");
        System.out.println("5. Follows the Open/Closed Principle");
    }
}