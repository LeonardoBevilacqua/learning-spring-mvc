/**
 * ConcreteCommand - implements the Command interface and defines the binding
 * between a Receiver object and an action. It calls the appropriate methods
 * on the receiver to carry out the request.
 */
public class ConcreteCommand implements Command {
    private Receiver receiver;

    public ConcreteCommand(Receiver receiver) {
        this.receiver = receiver;
    }

    @Override
    public void execute() {
        System.out.println("ConcreteCommand: Executing command");
        receiver.action();
    }
}