/**
 * Demo class for State pattern. Shows how the State pattern allows an object to
 * change its behavior when its internal state changes.
 */
public class Demo {
  public static void main(String[] args) {
    System.out.println("=== State Pattern Demo ===\n");

    // Create states
    State stateA = new ConcreteStateA();
    State stateB = new ConcreteStateB();

    // Create context with initial state A
    Context context = new Context(stateA);

    System.out.println("Context initial state: State A");
    System.out.println();

    System.out.println("Client: Requesting context operation");
    context.request();
    System.out.println("Context current state: " + (context.getState() == stateA ? "State A" : "State B"));
    System.out.println();

    System.out.println("Client: Requesting context operation again");
    context.request();
    System.out.println("Context current state: " + (context.getState() == stateA ? "State A" : "State B"));
    System.out.println();

    System.out.println("Client: Changing to State B");
    context.setState(stateB);
    context.request();
    System.out.println("Context current state: " + (context.getState() == stateA ? "State A" : "State B"));
    System.out.println();

    System.out.println("State pattern benefits:");
    System.out.println("1. Improves code organization by encapsulating state-specific behavior");
    System.out.println("2. Makes state transitions explicit");
    System.out.println("3. Follows the Open/Closed Principle");
    System.out.println("4. Follows the Single Responsibility Principle");
  }
}
