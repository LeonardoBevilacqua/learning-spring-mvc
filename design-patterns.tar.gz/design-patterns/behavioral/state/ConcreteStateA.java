/**
 * ConcreteStateA - implements the behavior associated with the A state.
 */
public class ConcreteStateA implements State {
    @Override
    public void handle(Context context) {
        System.out.println("ConcreteStateA: Handling request in State A");
        context.setState(this);
    }
}