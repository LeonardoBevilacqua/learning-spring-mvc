/**
 * ConcreteStateB - implements the behavior associated with the B state.
 */
public class ConcreteStateB implements State {
    @Override
    public void handle(Context context) {
        System.out.println("ConcreteStateB: Handling request in State B");
        context.setState(this);
    }
}