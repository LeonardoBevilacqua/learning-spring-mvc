/**
 * Context - maintains an instance of a ConcreteState subclass that defines the
 * current state of the Context.
 */
public class Context {
  private State state;

  public Context(State initialState) {
    this.state = initialState;
  }

  public void setState(State state) {
    this.state = state;
  }

  public void request() {
    System.out.println("Context: Received request");
    state.handle(this);
  }

  public State getState() {
    return state;
  }
}
