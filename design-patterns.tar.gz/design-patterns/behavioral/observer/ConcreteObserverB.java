/**
 * ConcreteObserverB - implements the Observer interface to update itself
 * for any changes in the Subject.
 */
public class ConcreteObserverB extends Observer {
    public ConcreteObserverB(Subject subject) {
        this.subject = subject;
        this.subject.attach(this);
    }

    @Override
    public void update() {
        System.out.println("ConcreteObserverB: Reacted to the subject's state change: " + subject.getState());
    }
}