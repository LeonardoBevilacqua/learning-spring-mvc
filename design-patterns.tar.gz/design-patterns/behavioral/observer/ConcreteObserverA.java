/**
 * ConcreteObserverA - implements the Observer interface to update itself
 * for any changes in the Subject.
 */
public class ConcreteObserverA extends Observer {
    public ConcreteObserverA(Subject subject) {
        this.subject = subject;
        this.subject.attach(this);
    }

    @Override
    public void update() {
        System.out.println("ConcreteObserverA: Reacted to the subject's state change: " + subject.getState());
    }
}