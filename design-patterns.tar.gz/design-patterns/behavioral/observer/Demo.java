/**
 * Demo class for Observer pattern.
 * Shows how the Observer pattern notifies multiple objects about state changes.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Observer Pattern Demo ===\n");

        // Create subject
        Subject subject = new Subject();

        // Create observers and attach them to the subject
        new ConcreteObserverA(subject);
        new ConcreteObserverB(subject);

        System.out.println("Observers are attached to the subject");
        System.out.println();

        System.out.println("Client: Setting subject state to 10");
        subject.setState(10);
        System.out.println();

        System.out.println("Client: Setting subject state to 20");
        subject.setState(20);
        System.out.println();

        System.out.println("Client: Setting subject state to 30");
        subject.setState(30);
        System.out.println();

        System.out.println("Observer pattern benefits:");
        System.out.println("1. Provides a way for multiple objects to be notified of state changes");
        System.out.println("2. Follows the Open/Closed Principle");
        System.out.println("3. Allows decoupling between Subject and Observer");
        System.out.println("4. Supports broadcast communication");
    }
}