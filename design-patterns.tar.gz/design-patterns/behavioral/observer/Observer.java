/**
 * Observer - defines an updating interface for objects that should be notified
 * of changes in a Subject.
 */
public abstract class Observer {
    protected Subject subject;
    public abstract void update();
}