import java.util.ArrayList;
import java.util.List;

/**
 * CareTaker - never operates on or examines the contents of a Memento.
 * It merely keeps a collection of Mementos (for example, in a stack or list).
 */
public class CareTaker {
    private List<Memento> mementos = new ArrayList<>();

    public void addMemento(Memento memento) {
        mementos.add(memento);
    }

    public Memento getMemento(int index) {
        if (index >= 0 && index < mementos.size()) {
            return mementos.get(index);
        }
        return null;
    }

    public Memento getLatestMemento() {
        if (!mementos.isEmpty()) {
            return mementos.get(mementos.size() - 1);
        }
        return null;
    }
}