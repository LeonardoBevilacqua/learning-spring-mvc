/**
 * Originator - creates a Memento containing a snapshot of its current internal state.
 * It uses the Memento to restore its internal state.
 */
public class Originator {
    private String state;

    public void setState(String state) {
        System.out.println("Originator: Setting state = " + state);
        this.state = state;
    }

    public String getState() {
        return state;
    }

    public Memento createMemento() {
        System.out.println("Originator: Creating memento with state = " + state);
        return new Memento(state);
    }

    public void restoreFromMemento(Memento memento) {
        state = memento.getState();
        System.out.println("Originator: State restored from memento = " + state);
    }
}