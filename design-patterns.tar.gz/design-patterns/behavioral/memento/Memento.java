/**
 * Memento - stores the internal state of an object at a particular time.
 * It is a token that represents a specific state of the Originator.
 */
public class Memento {
    private String state;

    public Memento(String state) {
        this.state = state;
    }

    public String getState() {
        return state;
    }
}