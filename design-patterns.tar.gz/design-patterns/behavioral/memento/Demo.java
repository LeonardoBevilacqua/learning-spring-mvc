/**
 * Demo class for Memento pattern.
 * Shows how the Memento pattern captures and restores an object's state.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Memento Pattern Demo ===\n");

        Originator originator = new Originator();
        CareTaker careTaker = new CareTaker();

        System.out.println("Client: Setting originator state to 'State 1'");
        originator.setState("State 1");
        careTaker.addMemento(originator.createMemento());
        System.out.println();

        System.out.println("Client: Setting originator state to 'State 2'");
        originator.setState("State 2");
        careTaker.addMemento(originator.createMemento());
        System.out.println();

        System.out.println("Client: Setting originator state to 'State 3'");
        originator.setState("State 3");
        careTaker.addMemento(originator.createMemento());
        System.out.println();

        System.out.println("Client: Restoring originator to 'State 2'");
        originator.restoreFromMemento(careTaker.getMemento(1));
        System.out.println();

        System.out.println("Client: Restoring originator to 'State 1'");
        originator.restoreFromMemento(careTaker.getMemento(0));
        System.out.println();

        System.out.println("Client: Restoring originator to latest state ('State 3')");
        originator.restoreFromMemento(careTaker.getLatestMemento());
        System.out.println();

        System.out.println("Memento pattern benefits:");
        System.out.println("1. Preserves encapsulation of the Originator's state");
        System.out.println("2. Simplifies Originator by not requiring a wide array of internal states");
        System.out.println("3. Allows undo/redo operations");
        System.out.println("4. Follows the Single Responsibility Principle");
    }
}