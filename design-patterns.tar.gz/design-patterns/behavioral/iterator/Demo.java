/**
 * Demo class for Iterator pattern.
 * Shows how the Iterator pattern provides a way to access elements of a collection sequentially.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Iterator Pattern Demo ===\n");

        // Create an aggregate
        ConcreteAggregate aggregate = new ConcreteAggregate(5);
        aggregate.add("Item 1");
        aggregate.add("Item 2");
        aggregate.add("Item 3");
        aggregate.add("Item 4");
        aggregate.add("Item 5");

        System.out.println("Aggregate items:");
        System.out.println("  - Item 1");
        System.out.println("  - Item 2");
        System.out.println("  - Item 3");
        System.out.println("  - Item 4");
        System.out.println("  - Item 5");
        System.out.println();

        // Create iterator and traverse the aggregate
        Iterator iterator = aggregate.createIterator();
        System.out.println("Traversing the aggregate using Iterator:");
        while (iterator.hasNext()) {
            Object item = iterator.next();
            System.out.println("  - " + item);
        }
        System.out.println();

        System.out.println("Iterator pattern benefits:");
        System.out.println("1. Supports variations in traversal of an aggregate");
        System.out.println("2. Simplifies the aggregate interface");
        System.out.println("3. Allows multiple traversals simultaneously");
        System.out.println("4. Follows the Single Responsibility Principle");
    }
}