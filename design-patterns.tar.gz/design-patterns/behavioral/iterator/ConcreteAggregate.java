/**
 * ConcreteAggregate - implements the Aggregate interface and creates a
 * ConcreteIterator for traversing its elements.
 */
public class ConcreteAggregate implements Aggregate {
    private Object[] items;
    private int count;

    public ConcreteAggregate(int size) {
        items = new Object[size];
        count = 0;
    }

    public void add(Object item) {
        if (count < items.length) {
            items[count++] = item;
        }
    }

    public Object get(int index) {
        if (index >= 0 && index < count) {
            return items[index];
        }
        return null;
    }

    public int getSize() {
        return count;
    }

    @Override
    public Iterator createIterator() {
        return new ConcreteIterator(this);
    }
}