/**
 * ConcreteIterator - implements the Iterator interface and keeps track of
 * the current position in the traversal.
 */
public class ConcreteIterator implements Iterator {
    private ConcreteAggregate aggregate;
    private int index;

    public ConcreteIterator(ConcreteAggregate aggregate) {
        this.aggregate = aggregate;
        this.index = 0;
    }

    @Override
    public boolean hasNext() {
        return index < aggregate.getSize();
    }

    @Override
    public Object next() {
        if (hasNext()) {
            return aggregate.get(index++);
        }
        return null;
    }
}