/**
 * ConcreteClassA - implements the primitive operations of the algorithm.
 */
public class ConcreteClassA extends AbstractClass {
  @Override
  protected void primitiveOperation1() {
    System.out.println("ConcreteClassA: Step 1 - Primitive operation 1 (different implementation)");
  }

  @Override
  protected void hook() {
    System.out.println("ConcreteClassA: Hook - Additional step specific to ConcreteClassA");
  }
}
