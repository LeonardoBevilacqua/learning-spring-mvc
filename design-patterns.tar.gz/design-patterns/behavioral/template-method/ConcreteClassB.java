/**
 * ConcreteClassB - implements the primitive operations of the algorithm
 * differently.
 */
public class ConcreteClassB extends AbstractClass {
  @Override
  protected void primitiveOperation2() {
    System.out.println("ConcreteClassB: Step 2 - Primitive operation 2 (different implementation)");
  }

  // This class does not override the hook method, so it uses the default
  // implementation
}
