/**
 * AbstractClass - defines a template method that contains a skeleton of an
 * algorithm. It also defines primitive operations that subclasses will
 * implement.
 */
public abstract class AbstractClass {
  // Template method - final to prevent subclasses from changing the algorithm
  // structure
  public final void templateMethod() {
    primitiveOperation1();
    primitiveOperation2();
    hook();
  }

  // Primitive operations - to be implemented by subclasses
  protected void primitiveOperation1() {
    System.out.println("AbstractClass: Step 1 - Primitive operation 1");
  }

  protected void primitiveOperation2() {
    System.out.println("AbstractClass: Step 2 - Primitive operation 2");
  }

  // Hook - optional operation that subclasses can override
  protected void hook() {
    // Default implementation does nothing
  }
}
