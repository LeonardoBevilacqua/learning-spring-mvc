/**
 * Demo class for Template Method pattern.
 * Shows how the Template Method pattern defines the skeleton of an algorithm in a method.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Template Method Pattern Demo ===\n");

        System.out.println("Client: Using ConcreteClassA to execute the algorithm");
        AbstractClass classA = new ConcreteClassA();
        classA.templateMethod();
        System.out.println();

        System.out.println("Client: Using ConcreteClassB to execute the algorithm");
        AbstractClass classB = new ConcreteClassB();
        classB.templateMethod();
        System.out.println();

        System.out.println("Template Method pattern benefits:");
        System.out.println("1. Defines the skeleton of an algorithm in a method");
        System.out.println("2. Allows subclasses to redefine certain steps of the algorithm");
        System.out.println("3. Follows the Open/Closed Principle");
        System.out.println("4. Avoids code duplication");
        System.out.println("5. Follows the Hollywood Principle (Don't call us, we'll call you)");
    }
}