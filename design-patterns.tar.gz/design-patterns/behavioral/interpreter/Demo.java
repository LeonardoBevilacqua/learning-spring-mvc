/**
 * Demo class for Interpreter pattern.
 * Shows how the Interpreter pattern can evaluate expressions following a grammar.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Interpreter Pattern Demo ===\n");

        // Create context and assign variables
        Context context = new Context();
        context.assign('A', 5);
        context.assign('B', 10);
        context.assign('C', 15);

        System.out.println("Context variables:");
        System.out.println("  A = 5");
        System.out.println("  B = 10");
        System.out.println("  C = 15");
        System.out.println();

        // Create expression: A + B * C
        AbstractExpression expression = new NonterminalExpression(
            new TerminalExpression('A'),
            new NonterminalExpression(
                new TerminalExpression('B'),
                new TerminalExpression('C'),
                '*'
            ),
            '+'
        );

        System.out.println("Expression: A + B * C");
        int result = expression.interpret(context);
        System.out.println("Result: " + result);
        System.out.println();

        System.out.println("Interpreter pattern benefits:");
        System.out.println("1. Allows defining a grammar for a language");
        System.out.println("2. Makes it easy to change/extend the grammar");
        System.out.println("3. Simplifies implementation of the grammar");
        System.out.println("4. Each symbol becomes a class, making it easier to manage");
    }
}