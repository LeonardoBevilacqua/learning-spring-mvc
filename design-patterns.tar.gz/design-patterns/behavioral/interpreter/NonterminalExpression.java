/**
 * NonterminalExpression - implements the Interpret operation for nonterminal
 * symbols in the grammar. It always refers to other expressions.
 */
public class NonterminalExpression extends AbstractExpression {
    private AbstractExpression leftExpression;
    private AbstractExpression rightExpression;
    private char operator;

    public NonterminalExpression(AbstractExpression left, AbstractExpression right, char operator) {
        this.leftExpression = left;
        this.rightExpression = right;
        this.operator = operator;
    }

    @Override
    public int interpret(Context context) {
        int leftValue = leftExpression.interpret(context);
        int rightValue = rightExpression.interpret(context);

        switch (operator) {
            case '+':
                return leftValue + rightValue;
            case '-':
                return leftValue - rightValue;
            case '*':
                return leftValue * rightValue;
            case '/':
                if (rightValue != 0) {
                    return leftValue / rightValue;
                } else {
                    throw new ArithmeticException("Division by zero");
                }
            default:
                throw new IllegalArgumentException("Unknown operator: " + operator);
        }
    }
}