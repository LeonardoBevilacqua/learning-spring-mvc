/**
 * AbstractExpression - declares an abstract Interpret operation that all nodes
 * (terminal and nonterminal) must implement.
 */
public abstract class AbstractExpression {
    public abstract int interpret(Context context);
}