/**
 * TerminalExpression - implements the Interpret operation for terminal symbols
 * in the grammar. It represents a single element of the language.
 */
public class TerminalExpression extends AbstractExpression {
    private char variable;

    public TerminalExpression(char variable) {
        this.variable = variable;
    }

    @Override
    public int interpret(Context context) {
        // Check if the variable exists in the context
        if (context.get(variable) != null) {
            return context.get(variable);
        }
        return 0;
    }
}