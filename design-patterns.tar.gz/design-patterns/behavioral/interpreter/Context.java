import java.util.HashMap;
import java.util.Map;

/**
 * Context - contains the global information that is common to all expressions.
 * It's used to store variables and their values.
 */
public class Context {
    private Map<Character, Integer> variables = new HashMap<>();

    public void assign(char variable, int value) {
        variables.put(variable, value);
    }

    public Integer get(char variable) {
        return variables.get(variable);
    }
}