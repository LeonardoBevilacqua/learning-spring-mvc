/**
 * Implementor interface - defines the interface for implementation classes.
 */
public interface Implementor {
    void operationImpl();
}