/**
 * Abstraction - maintains a reference to the Implementor and defines the abstraction's interface.
 */
public abstract class Abstraction {
    protected Implementor implementor;

    public Abstraction(Implementor implementor) {
        this.implementor = implementor;
    }

    public abstract void operation();
}