/**
 * Demo class for Bridge pattern.
 * Shows how to decouple an abstraction from its implementation.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Bridge Pattern Demo ===\n");

        // Using Implementation A
        System.out.println("--- Using Implementation A ---");
        Abstraction abstractionA = new RefinedAbstraction(new ConcreteImplementorA());
        abstractionA.operation();
        System.out.println();

        // Using Implementation B
        System.out.println("--- Using Implementation B ---");
        Abstraction abstractionB = new RefinedAbstraction(new ConcreteImplementorB());
        abstractionB.operation();
        System.out.println();

        // Bridge pattern benefits:
        // 1. Decouples abstraction from implementation
        // 2. Allows independent variation of abstraction and implementation
        // 3. Follows the Open/Closed Principle
    }
}