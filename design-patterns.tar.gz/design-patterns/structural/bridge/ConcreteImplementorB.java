/**
 * ConcreteImplementorB - another implementation of the Implementor interface.
 */
public class ConcreteImplementorB implements Implementor {
    @Override
    public void operationImpl() {
        System.out.println("ConcreteImplementorB: Implementation B");
    }
}