/**
 * ConcreteImplementorA - one implementation of the Implementor interface.
 */
public class ConcreteImplementorA implements Implementor {
    @Override
    public void operationImpl() {
        System.out.println("ConcreteImplementorA: Implementation A");
    }
}