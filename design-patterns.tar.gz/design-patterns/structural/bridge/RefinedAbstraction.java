/**
 * RefinedAbstraction - extends the Abstraction with a refined implementation.
 */
public class RefinedAbstraction extends Abstraction {

    public RefinedAbstraction(Implementor implementor) {
        super(implementor);
    }

    @Override
    public void operation() {
        System.out.print("RefinedAbstraction: ");
        implementor.operationImpl();
    }
}