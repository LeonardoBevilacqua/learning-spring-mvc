/**
 * ConcreteFlyweight - implements the Flyweight interface and adds storage
 * for intrinsic state, if any. A concrete flyweight must be sharable and
 * must be able to control its own extrinsic state.
 */
public class ConcreteFlyweight implements Flyweight {
    private String intrinsicState;

    public ConcreteFlyweight(String intrinsicState) {
        this.intrinsicState = intrinsicState;
        System.out.println("  - Creating ConcreteFlyweight with intrinsic state: " + intrinsicState);
    }

    @Override
    public void operation(String extrinsicState) {
        System.out.println("ConcreteFlyweight: Intrinsic state = " + intrinsicState + 
                         ", Extrinsic state = " + extrinsicState);
    }
}