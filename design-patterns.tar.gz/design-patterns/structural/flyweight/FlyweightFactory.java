/**
 * FlyweightFactory - creates and manages flyweight objects. It ensures that
 * flyweights are shared properly. When a client requests a flyweight, the
 * factory either returns an existing instance or creates a new one, if it
 * doesn't exist.
 */
import java.util.HashMap;
import java.util.Map;

public class FlyweightFactory {
    private Map<String, Flyweight> flyweights = new HashMap<>();

    public Flyweight getFlyweight(String key) {
        if (!flyweights.containsKey(key)) {
            flyweights.put(key, new ConcreteFlyweight(key));
        }
        return flyweights.get(key);
    }

    public int getTotalFlyweightsCreated() {
        return flyweights.size();
    }
}