/**
 * Demo class for Flyweight pattern.
 * Shows how the Flyweight pattern shares objects to reduce memory usage.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Flyweight Pattern Demo ===\n");

        FlyweightFactory factory = new FlyweightFactory();

        System.out.println("Client: I need flyweights with different intrinsic states.");
        
        // Get flyweights with different keys
        Flyweight flyweight1 = factory.getFlyweight("A");
        Flyweight flyweight2 = factory.getFlyweight("B");
        Flyweight flyweight3 = factory.getFlyweight("C");
        Flyweight flyweight4 = factory.getFlyweight("A"); // This will reuse existing flyweight1

        System.out.println("\nPerforming operations with flyweights:");
        flyweight1.operation("Extrinsic State 1");
        flyweight2.operation("Extrinsic State 2");
        flyweight3.operation("Extrinsic State 3");
        flyweight4.operation("Extrinsic State 4");

        System.out.println("\nTotal flyweights created: " + factory.getTotalFlyweightsCreated());
        System.out.println("\nFlyweight pattern benefits:");
        System.out.println("1. Reduces memory usage by sharing objects");
        System.out.println("2. Improves performance by caching");
        System.out.println("3. Follows the DRY principle (Don't Repeat Yourself)");
        System.out.println("4. Useful when many similar objects are used");
    }
}