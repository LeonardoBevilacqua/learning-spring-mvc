/**
 * Flyweight - declares an interface through which flyweights can receive
 * and respond to extrinsic state.
 */
public interface Flyweight {
    void operation(String extrinsicState);
}