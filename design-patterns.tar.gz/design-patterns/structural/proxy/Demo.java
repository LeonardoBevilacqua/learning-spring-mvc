/**
 * Demo class for Proxy pattern.
 * Shows how the Proxy pattern provides a surrogate or placeholder for another object.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Proxy Pattern Demo ===\n");

        // Create a proxy object
        Subject proxy = new Proxy();

        System.out.println("Client: Executing the request through proxy");
        proxy.request();
        System.out.println();

        System.out.println("Client: Executing the request again through proxy");
        proxy.request();
        System.out.println();

        System.out.println("\nProxy pattern benefits:");
        System.out.println("1. Provides a surrogate object for access control");
        System.out.println("2. Allows lazy loading or virtual proxy");
        System.out.println("3. Enables remote proxy for objects in different address spaces");
        System.out.println("4. Supports protection proxy for access control based on role");
        System.out.println("5. Follows the Principle of Least Knowledge");
    }
}