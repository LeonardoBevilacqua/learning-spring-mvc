/**
 * RealSubject - the actual object that the proxy represents. It is usually
 * the object that does the real work.
 */
public class RealSubject implements Subject {
    @Override
    public void request() {
        System.out.println("RealSubject: Handling request");
    }
}