/**
 * Subject - defines the common interface for RealSubject and Proxy objects.
 */
public interface Subject {
    void request();
}