/**
 * Proxy - maintains a reference to the real subject. It controls access to
 * the real subject and may be responsible for creating and deleting it.
 */
public class Proxy implements Subject {
    private RealSubject realSubject;

    @Override
    public void request() {
        if (realSubject == null) {
            System.out.println("Proxy: Creating real subject");
            realSubject = new RealSubject();
        }
        
        System.out.println("Proxy: Checking access prior to firing a real request");
        
        // Perform any other operations before the real request
        preRequest();
        
        realSubject.request();
        
        // Perform any other operations after the real request
        postRequest();
    }
    
    private void preRequest() {
        System.out.println("  - Proxy: Pre-processing request");
    }
    
    private void postRequest() {
        System.out.println("  - Proxy: Post-processing request");
    }
}