/**
 * Component interface - declares the interface for all objects in the composition.
 */
public interface Component {
    void operation();
    void add(Component component);
    void remove(Component component);
    Component getChild(int index);
}