/**
 * Adaptee - the existing class with an incompatible interface.
 */
public class Adaptee {
    public void specificRequest() {
        System.out.println("Adaptee: specificRequest() called");
    }
}