/**
 * Demo class for Adapter pattern.
 * Shows how to use an incompatible class through an adapter.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Adapter Pattern Demo ===\n");

        // The client expects a Target interface
        Target target = new Adapter(new Adaptee());

        // Client can now use the Adaptee through the Target interface
        target.request();

        System.out.println();
        System.out.println("Adapter pattern benefits:");
        System.out.println("1. Allows incompatible classes to work together");
        System.out.println("2. Promotes reusability of existing classes");
        System.out.println("3. Follows the Open/Closed Principle");
    }
}