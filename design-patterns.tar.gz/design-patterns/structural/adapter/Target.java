/**
 * Target interface - the interface that the client expects.
 */
public interface Target {
    void request();
}