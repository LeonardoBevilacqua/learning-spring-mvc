/**
 * Adapter - converts the interface of Adaptee into the Target interface.
 * Uses object adaptation (composition) to wrap the Adaptee.
 */
public class Adapter implements Target {
    private final Adaptee adaptee;

    public Adapter(Adaptee adaptee) {
        this.adaptee = adaptee;
    }

    @Override
    public void request() {
        System.out.print("Adapter: ");
        adaptee.specificRequest();
    }
}