/**
 * Decorator - maintains a reference to a Component object and defines an interface
 * that conforms to Component's interface. It also provides a default implementation
 * that forwards requests to the Component.
 */
public abstract class Decorator implements Component {
    protected Component component;

    public Decorator(Component component) {
        this.component = component;
    }

    @Override
    public void operation() {
        component.operation();
    }
}