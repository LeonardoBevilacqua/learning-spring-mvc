/**
 * ConcreteDecoratorB - extends the Decorator class and adds different responsibilities.
 * This class adds different specific functionality to the component.
 */
public class ConcreteDecoratorB extends Decorator {
    public ConcreteDecoratorB(Component component) {
        super(component);
    }

    @Override
    public void operation() {
        System.out.print("ConcreteDecoratorB: ");
        component.operation();
        addedBehavior();
    }

    private void addedBehavior() {
        System.out.println(" + Extra feature B");
    }
}