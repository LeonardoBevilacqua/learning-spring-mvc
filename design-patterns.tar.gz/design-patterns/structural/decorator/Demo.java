/**
 * Demo class for Decorator pattern.
 * Shows how to dynamically add responsibilities to an object.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Decorator Pattern Demo ===\n");

        // Create a ConcreteComponent
        Component component = new ConcreteComponent();
        System.out.print("Basic component: ");
        component.operation();
        System.out.println();

        // Decorate with ConcreteDecoratorA
        Component decoratedA = new ConcreteDecoratorA(component);
        System.out.print("With ConcreteDecoratorA: ");
        decoratedA.operation();
        System.out.println();

        // Decorate with ConcreteDecoratorB
        Component decoratedB = new ConcreteDecoratorB(component);
        System.out.print("With ConcreteDecoratorB: ");
        decoratedB.operation();
        System.out.println();

        // Multiple decorations
        Component multipleDecorations = new ConcreteDecoratorB(
            new ConcreteDecoratorA(component)
        );
        System.out.print("Multiple decorations: ");
        multipleDecorations.operation();
        System.out.println();

        System.out.println("\nDecorator pattern benefits:");
        System.out.println("1. Allows adding responsibilities dynamically");
        System.out.println("2. Provides flexibility beyond static inheritance");
        System.out.println("3. Follows the Open/Closed Principle");
        System.out.println("4. Avoids feature-laden classes high in the hierarchy");
    }
}