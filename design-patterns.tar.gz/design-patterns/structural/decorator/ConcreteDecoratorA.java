/**
 * ConcreteDecoratorA - extends the Decorator class and adds responsibilities.
 * This class adds specific functionality to the component.
 */
public class ConcreteDecoratorA extends Decorator {
    public ConcreteDecoratorA(Component component) {
        super(component);
    }

    @Override
    public void operation() {
        System.out.print("ConcreteDecoratorA: ");
        component.operation();
        addedBehavior();
    }

    private void addedBehavior() {
        System.out.println(" + Extra feature A");
    }
}