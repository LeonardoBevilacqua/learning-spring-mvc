/**
 * ConcreteComponent - the basic implementation of the Component interface.
 * This is the object to which additional responsibilities can be attached.
 */
public class ConcreteComponent implements Component {
    @Override
    public void operation() {
        System.out.println("ConcreteComponent: Basic operation");
    }
}