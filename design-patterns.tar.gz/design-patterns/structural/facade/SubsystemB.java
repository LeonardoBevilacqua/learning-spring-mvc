/**
 * SubsystemB - another subsystem class with its own complex logic.
 */
public class SubsystemB {
    public void operationB() {
        System.out.println("  - SubsystemB operation");
    }
}