/**
 * SubsystemC - another subsystem class with its own complex logic.
 */
public class SubsystemC {
    public void operationC() {
        System.out.println("  - SubsystemC operation");
    }
}