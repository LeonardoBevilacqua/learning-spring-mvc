/**
 * Demo class for Facade pattern.
 * Shows how the Facade pattern simplifies complex subsystem interactions.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Facade Pattern Demo ===\n");

        // Use the Facade to simplify complex subsystem interactions
        Facade facade = new Facade();

        System.out.println("Client calling simpleOperation() on Facade:");
        facade.simpleOperation();
        System.out.println();

        System.out.println("Client calling anotherSimpleOperation() on Facade:");
        facade.anotherSimpleOperation();
        System.out.println();

        System.out.println("\nFacade pattern benefits:");
        System.out.println("1. Provides a simple interface to a complex subsystem");
        System.out.println("2. Reduces communication and dependencies between subsystems");
        System.out.println("3. Protects clients from complexities of the subsystem components");
        System.out.println("4. Follows the Principle of Least Knowledge (Law of Demeter)");
    }
}