/**
 * SubsystemA - one of the subsystem classes with its own complex logic.
 */
public class SubsystemA {
    public void operationA() {
        System.out.println("  - SubsystemA operation");
    }
}