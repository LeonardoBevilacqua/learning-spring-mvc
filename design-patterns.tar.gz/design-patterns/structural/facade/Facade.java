/**
 * Facade - provides a simplified interface to the complex subsystem.
 * It delegates client requests to the appropriate subsystem objects.
 */
public class Facade {
    private SubsystemA subsystemA;
    private SubsystemB subsystemB;
    private SubsystemC subsystemC;

    public Facade() {
        this.subsystemA = new SubsystemA();
        this.subsystemB = new SubsystemB();
        this.subsystemC = new SubsystemC();
    }

    /**
     * Simplified operation that hides the complexity of the subsystem.
     */
    public void simpleOperation() {
        System.out.println("Facade: Initiating simple operation...");
        subsystemA.operationA();
        subsystemB.operationB();
        subsystemC.operationC();
        System.out.println("Facade: Simple operation completed!");
    }

    /**
     * Another simplified operation.
     */
    public void anotherSimpleOperation() {
        System.out.println("Facade: Initiating another simple operation...");
        subsystemA.operationA();
        subsystemB.operationB();
        System.out.println("Facade: Another simple operation completed!");
    }
}