/**
 * Demo class for Abstract Factory pattern.
 * Shows how to use abstract factories to create families of related products.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Abstract Factory Pattern Demo ===\n");

        // Using Factory 1 (Variant 1)
        System.out.println("--- Using ConcreteFactory1 (Variant 1) ---");
        AbstractFactory factory1 = new ConcreteFactory1();
        ProductA productA1 = factory1.createProductA();
        ProductB productB1 = factory1.createProductB();
        productA1.use();
        productB1.use();
        System.out.println();

        // Using Factory 2 (Variant 2)
        System.out.println("--- Using ConcreteFactory2 (Variant 2) ---");
        AbstractFactory factory2 = new ConcreteFactory2();
        ProductA productA2 = factory2.createProductA();
        ProductB productB2 = factory2.createProductB();
        productA2.use();
        productB2.use();
        System.out.println();

        // Abstract Factory pattern benefits:
        // 1. Ensures compatibility between products from the same family
        // 2. Encapsulates the creation of product families
        // 3. Easy to switch between product families
    }
}