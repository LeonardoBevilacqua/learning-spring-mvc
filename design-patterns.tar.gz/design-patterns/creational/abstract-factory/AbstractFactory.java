/**
 * AbstractFactory interface - declares methods for creating abstract products.
 */
public interface AbstractFactory {
    ProductA createProductA();
    ProductB createProductB();
}