/**
 * ConcreteProductB2 - implementation of ProductB for variant 2.
 */
public class ConcreteProductB2 implements ProductB {
    @Override
    public void use() {
        System.out.println("Using ConcreteProductB2 (Variant 2)");
    }
}