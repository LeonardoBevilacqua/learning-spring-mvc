/**
 * ConcreteProductA2 - implementation of ProductA for variant 2.
 */
public class ConcreteProductA2 implements ProductA {
    @Override
    public void use() {
        System.out.println("Using ConcreteProductA2 (Variant 2)");
    }
}