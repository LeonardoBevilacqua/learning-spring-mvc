/**
 * ProductB interface - represents another type of product in the family.
 */
public interface ProductB {
    void use();
}