/**
 * ProductA interface - represents one type of product in the family.
 */
public interface ProductA {
    void use();
}