/**
 * ConcreteProductA1 - implementation of ProductA for variant 1.
 */
public class ConcreteProductA1 implements ProductA {
    @Override
    public void use() {
        System.out.println("Using ConcreteProductA1 (Variant 1)");
    }
}