/**
 * ConcreteProductB1 - implementation of ProductB for variant 1.
 */
public class ConcreteProductB1 implements ProductB {
    @Override
    public void use() {
        System.out.println("Using ConcreteProductB1 (Variant 1)");
    }
}