/**
 * Product - the complex object being built.
 * Contains multiple parts that can be configured.
 */
public class Product {
    private String partA;
    private String partB;
    private String partC;
    private boolean featureX;
    private boolean featureY;

    // Private constructor - use Builder to create instances
    private Product(Builder builder) {
        this.partA = builder.partA;
        this.partB = builder.partB;
        this.partC = builder.partC;
        this.featureX = builder.featureX;
        this.featureY = builder.featureY;
    }

    @Override
    public String toString() {
        return "Product{" +
                "partA='" + partA + '\'' +
                ", partB='" + partB + '\'' +
                ", partC='" + partC + '\'' +
                ", featureX=" + featureX +
                ", featureY=" + featureY +
                '}';
    }

    /**
     * Builder - static nested class for building Product instances.
     * Provides a fluent interface for constructing complex objects.
     */
    public static class Builder {
        // Required parameters
        private final String partA;
        private final String partB;

        // Optional parameters - initialized with default values
        private String partC = "default";
        private boolean featureX = false;
        private boolean featureY = false;

        public Builder(String partA, String partB) {
            this.partA = partA;
            this.partB = partB;
        }

        public Builder partC(String partC) {
            this.partC = partC;
            return this;
        }

        public Builder featureX(boolean featureX) {
            this.featureX = featureX;
            return this;
        }

        public Builder featureY(boolean featureY) {
            this.featureY = featureY;
            return this;
        }

        public Product build() {
            return new Product(this);
        }
    }
}