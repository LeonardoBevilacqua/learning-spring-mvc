/**
 * Demo class for Builder pattern.
 * Shows how to use the Builder to construct complex objects step by step.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Builder Pattern Demo ===\n");

        // Creating a simple product with only required parts
        Product simpleProduct = new Product.Builder("A1", "B1").build();
        System.out.println("Simple Product: " + simpleProduct);
        System.out.println();

        // Creating a complex product with all options
        Product complexProduct = new Product.Builder("A2", "B2")
                .partC("C2")
                .featureX(true)
                .featureY(true)
                .build();
        System.out.println("Complex Product: " + complexProduct);
        System.out.println();

        // Creating another product with different configuration
        Product mediumProduct = new Product.Builder("A3", "B3")
                .partC("C3")
                .featureX(true)
                .build();
        System.out.println("Medium Product: " + mediumProduct);
        System.out.println();

        // Builder pattern benefits:
        // 1. Constructs complex objects step by step
        // 2. Provides a fluent API for better readability
        // 3. Ensures immutability of the final product
        // 4. Handles optional parameters elegantly
    }
}