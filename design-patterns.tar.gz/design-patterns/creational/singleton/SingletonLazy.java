/**
 * Singleton - Lazy Initialization (Thread-Safe with Double-Checked Locking)
 * The instance is created only when first requested.
 * More resource-efficient than eager initialization.
 */
public class SingletonLazy {
    // volatile ensures visibility of changes across threads
    private static volatile SingletonLazy instance;

    private SingletonLazy() {
        System.out.println("SingletonLazy: Instance created");
    }

    public static SingletonLazy getInstance() {
        if (instance == null) {
            synchronized (SingletonLazy.class) {
                if (instance == null) {
                    instance = new SingletonLazy();
                }
            }
        }
        return instance;
    }

    public void doSomething() {
        System.out.println("SingletonLazy: Doing something");
    }
}