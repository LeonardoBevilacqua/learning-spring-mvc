/**
 * Demo class for Singleton pattern implementations.
 * Shows how to use different Singleton implementations.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Singleton Pattern Demo ===\n");

        // Eager Initialization
        System.out.println("--- Eager Initialization ---");
        SingletonEager eager1 = SingletonEager.getInstance();
        SingletonEager eager2 = SingletonEager.getInstance();
        System.out.println("Same instance? " + (eager1 == eager2));
        eager1.doSomething();
        System.out.println();

        // Lazy Initialization (Thread-Safe)
        System.out.println("--- Lazy Initialization (Double-Checked Locking) ---");
        SingletonLazy lazy1 = SingletonLazy.getInstance();
        SingletonLazy lazy2 = SingletonLazy.getInstance();
        System.out.println("Same instance? " + (lazy1 == lazy2));
        lazy1.doSomething();
        System.out.println();

        // Enum Implementation
        System.out.println("--- Enum Implementation ---");
        SingletonEnum enum1 = SingletonEnum.INSTANCE;
        SingletonEnum enum2 = SingletonEnum.INSTANCE;
        System.out.println("Same instance? " + (enum1 == enum2));
        enum1.doSomething();
    }
}