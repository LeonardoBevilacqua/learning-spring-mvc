/**
 * Singleton - Eager Initialization
 * The instance is created when the class is loaded.
 * Thread-safe but may waste resources if never used.
 */
public class SingletonEager {
    private static final SingletonEager INSTANCE = new SingletonEager();

    private SingletonEager() {
        System.out.println("SingletonEager: Instance created");
    }

    public static SingletonEager getInstance() {
        return INSTANCE;
    }

    public void doSomething() {
        System.out.println("SingletonEager: Doing something");
    }
}