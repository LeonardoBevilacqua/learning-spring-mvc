/**
 * Singleton - Enum Implementation (Bill Pugh Solution alternative)
 * This is the most thread-safe and serialization-safe way to implement Singleton in Java.
 * The JVM guarantees that enum values are instantiated only once.
 */
public enum SingletonEnum {
    INSTANCE;

    private SingletonEnum() {
        System.out.println("SingletonEnum: Instance created");
    }

    public void doSomething() {
        System.out.println("SingletonEnum: Doing something");
    }
}