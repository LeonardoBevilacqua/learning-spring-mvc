/**
 * ProductFactory - creates Product instances based on type.
 * The factory encapsulates the object creation logic.
 */
public class ProductFactory {

    /**
     * Creates a product based on the given type.
     * @param type the type of product to create ("A" or "B")
     * @return the created Product
     * @throws IllegalArgumentException if type is unknown
     */
    public static Product createProduct(String type) {
        switch (type.toUpperCase()) {
            case "A":
                return new ConcreteProductA();
            case "B":
                return new ConcreteProductB();
            default:
                throw new IllegalArgumentException("Unknown product type: " + type);
        }
    }
}