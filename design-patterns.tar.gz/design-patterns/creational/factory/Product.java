/**
 * Product interface - defines the common interface for all products.
 */
public interface Product {
    void use();
    String getName();
}