/**
 * ConcreteProductA - a specific implementation of Product.
 */
public class ConcreteProductA implements Product {
    @Override
    public void use() {
        System.out.println("Using ConcreteProductA");
    }

    @Override
    public String getName() {
        return "ProductA";
    }
}