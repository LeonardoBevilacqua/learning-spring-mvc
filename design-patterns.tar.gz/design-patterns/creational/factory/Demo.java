/**
 * Demo class for Factory pattern.
 * Shows how to use the factory to create products without knowing their concrete classes.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Factory Pattern Demo ===\n");

        // Create products using the factory
        Product productA = ProductFactory.createProduct("A");
        Product productB = ProductFactory.createProduct("B");

        // Use products through their interface
        System.out.println("Product A: " + productA.getName());
        productA.use();
        System.out.println();

        System.out.println("Product B: " + productB.getName());
        productB.use();
        System.out.println();

        // Factory pattern benefits:
        // 1. Encapsulates object creation logic
        // 2. Promotes loose coupling
        // 3. Easy to add new product types
    }
}