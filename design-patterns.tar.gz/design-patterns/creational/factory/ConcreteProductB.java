/**
 * ConcreteProductB - another specific implementation of Product.
 */
public class ConcreteProductB implements Product {
    @Override
    public void use() {
        System.out.println("Using ConcreteProductB");
    }

    @Override
    public String getName() {
        return "ProductB";
    }
}