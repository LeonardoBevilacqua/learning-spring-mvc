/**
 * Demo class for Prototype pattern.
 * Shows how to create new objects by cloning existing ones.
 */
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Prototype Pattern Demo ===\n");

        // Create an original prototype
        ConcretePrototype original = new ConcretePrototype("Original", 100);
        System.out.println("Original: " + original);
        System.out.println();

        // Clone the prototype
        ConcretePrototype clone1 = (ConcretePrototype) original.clone();
        System.out.println("Clone 1 (before modification): " + clone1);
        System.out.println("Are they the same object? " + (original == clone1));
        System.out.println();

        // Modify the clone
        clone1.setValue(200);
        System.out.println("Clone 1 (after modification): " + clone1);
        System.out.println("Original (unchanged): " + original);
        System.out.println();

        // Create another clone
        ConcretePrototype clone2 = (ConcretePrototype) original.clone();
        clone2.setValue(300);
        System.out.println("Clone 2: " + clone2);
        System.out.println();

        // Prototype pattern benefits:
        // 1. Reduces the need for subclassing
        // 2. Creates objects at runtime with minimal performance cost
        // 3. Useful when object creation is expensive or complex
    }
}