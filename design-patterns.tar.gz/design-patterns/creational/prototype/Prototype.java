/**
 * Prototype interface - declares the clone method.
 */
public interface Prototype extends Cloneable {
    Prototype clone();
}